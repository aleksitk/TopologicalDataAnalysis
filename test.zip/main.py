# from simplicial import *
#
# # Create an empty simplicial complex with name C
# C = SimplicialComplex()
# s1 = C.addSimplex(id=1)  # Add a 0-simplex to C called 1.
# s2 = C.addSimplex(id=2)
# s3 = C.addSimplex(id=3)
# s4 = C.addSimplex(id=4)
# l12 = C.addSimplex(fs=[1, 2])
# l23 = C.addSimplex(fs=[2, 3])
# l31 = C.addSimplex(fs=[1, 3])
# print(C.bettiNumbers())
import matplotlib.pyplot as plt

# Read points from a text file
file_path = 'C:\\Users\\Admin\\Downloads\\data2.txt'  # Replace with the actual path to your file
with open(file_path, 'r') as file:
    lines = file.readlines()

# Extract x and y values from the file
points = [tuple(map(float, line.strip().split())) for line in lines]

# Extract x and y values
x_values, y_values = zip(*points)

# Plotting
plt.scatter(x_values, y_values, label='Points', color='blue')
plt.title('Scatter Plot of Points')
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.legend()
plt.show()

