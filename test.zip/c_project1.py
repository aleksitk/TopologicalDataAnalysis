import cv2
import numpy as np

# Read the image
image = cv2.imread('path/to/your/photo.jpg')

# Convert the image to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply GaussianBlur to reduce noise and help contour detection
blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Use Canny edge detector to find edges in the image
edges = cv2.Canny(blurred, 50, 150)

# Find contours in the edged image
contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Iterate through the contours and find the closed ones
closed_contours = []
for contour in contours:
    perimeter = cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, 0.02 * perimeter, True)

    if len(approx) >= 4:  # Assuming a closed shape has at least 4 vertices
        closed_contours.append(contour)

# Draw the contours on the original image
cv2.drawContours(image, closed_contours, -1, (0, 255, 0), 2)

# Display the result
cv2.imshow('Detected Shape', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
