import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from ripser import ripser
from persim import plot_diagrams
import numpy as np;
import multipers as mp
import gudhi as gd

n = 1000  # Change this to change the size of the data set
theta = np.random.uniform(low=0, high=2 * 3.1415, size=n)  # n points from a uniform distribution on [0, pi]
radius = np.random.normal(loc=3.0, scale=0.3, size=n)  # n points from the normal distribution with mean=3.0, sd=0.1
temp1 = radius * np.cos(theta)
temp2 = radius * np.sin(theta)
X = np.c_[temp1, temp2]
np.savetxt("C:\\Users\\Admin\\Downloads\\data1.csv", X, delimiter=",")  # Writes a .csv file.  Change the directory
plt.scatter(X[:, 0], X[:, 1], s=5);
plt.gca().set_aspect(1)
plt.savefig('C:\\Users\\Admin\\Downloads\\data1.png')  # Saves the image
diagrams = ripser(X)['dgms']
plot_diagrams(diagrams, show=True)
# plt.savefig('/home/matthew_zabka/Documents/Presentations/Georgia5/images/circle-diagram.png')
temp3 = np.random.uniform(low=-1.5, high=1.5, size=15)
temp4 = np.random.uniform(low=-1.5, high=1.5, size=15)
temp5 = np.c_[temp3, temp4]
Y = np.row_stack((X, temp5))  # Annulus with extra noise
# np.savetxt("/home/matthew_zabka/Documents/Presentations/Georgia5/data/data8.csv", Y, delimiter = ",") #Writes a
# .csv file.  Change the directory
plt.scatter(Y[:, 0], Y[:, 1], s=5);
plt.gca().set_aspect(1)
plt.title('Noisy Anulus')  # Adds a title to the data
diagrams = ripser(Y)['dgms']
plot_diagrams(diagrams, show=True)
