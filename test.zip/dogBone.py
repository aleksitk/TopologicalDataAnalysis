import kmapper as km
import sklearn
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

X1 = np.random.uniform(low=-2, high=-1, size=100)
X2 = np.random.uniform(low=-2, high=-1, size=100)
Y1 = -X1 - 1 + np.random.normal(loc=0, scale=0.1, size=100)
Y2 = X2 + 1 + np.random.normal(loc=0, scale=0.1, size=100)
X3 = np.random.uniform(low=-1, high=1, size=100)
Y3 = np.random.normal(loc=0, scale=0.1, size=100)
X4 = np.random.uniform(low=1, high=2, size=100)
X5 = np.random.uniform(low=1, high=2, size=100)
Y4 = X4 - 1 + np.random.normal(loc=0, scale=0.1, size=100)
Y5 = -X5 + 1 + np.random.normal(loc=0, scale=0.1, size=100)

X = np.concatenate((X1, X2, X3, X4, X5), axis=0)
Y = np.concatenate((Y1, Y2, Y3, Y4, Y5), axis=0)
plt.scatter(X, Y)
data = np.c_[X, Y]
# Initialize
mapper = km.KeplerMapper(verbose=1)

# Fit to and transform the data
projected_data = mapper.fit_transform(data, projection=[0, 1])  # X-Y axis

# Create a cover with 10 elements
cover = km.Cover(n_cubes=10)

# Create dictionary called 'graph' with nodes, edges and meta-information
graph = mapper.map(projected_data, data, cover=cover)

# Visualize it
mapper.visualize(graph, path_html="dogbone.html",
                 title="Our Example")
